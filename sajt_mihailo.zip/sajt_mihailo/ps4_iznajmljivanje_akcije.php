﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
	<head>
		<title> PS4 Iznajmljivanje akcije Beograd | Sony4 Iznajmljivanje popusti</title>
		<meta http-equiv="Content-Type" content="text/html"; charset="UTF-8" /> 
		<meta name="description" content="Iznajmljivanje Sony4 Beograd akcije! Besplatna dostava, PS4 Iznajmljivanje popusti Beograd" />
		<meta name="keywords" content="sony4 iznajmljivanje popusti, ps4 iznajmljivanje popusti, ps4 iznajmljivanje Beograd akcije, iznajmljivanje sony4 Beograd popusti"  lang="sr" xml:lang="sr" />
		<meta name="author" content="Nikola Mihajlovic" />
		<meta name="robots" content="all" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		
		<meta property="og:title" content="PS4 Iznajmljivanje Akcije | Beograd!" />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="http://www.ps4iznajmljivanje.rs/ps4_iznajmljivanje_akcije.php" />
        <meta property="og:image" content="http://www.ps4iznajmljivanje.rs/Mihailo%20sajt%20slike/ps4_iznajmljivanje_za_fb.png" /> 
		<meta property="article:author" content="https://www.facebook.com/nikola.a.mihajlovic" />
        <meta property="og:site_name" content="PS4 Iznajmljivanje Beograd" />
        <meta property="og:description" content="Sony 4 Iznajmljivanje Akcije. Brojne akcije koje dobijate svakodnevno, mogu smanjiti cenu iznajmljivanja i do 50%! Poziv na broj 062-182-1998." />
		
		<link rel="shortcut icon" href="Mihailo sajt slike/logo/favicon.jpg" type="image/x-icon">
		<link href='https://fonts.googleapis.com/css?family=Noto+Serif' rel='stylesheet' type='text/css'>
		<link rel="icon" href="Mihailo sajt slike/logo/favicon.jpg" type="image/x-icon">
		
			<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
		
		<script src="//code.jquery.com/jquery-1.10.2.js"></script>
		<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
			<script type="text/javascript" src="slider.js">
			</script>
			<script type="text/javascript" src="menjac.js"></script>
		<link rel="stylesheet" href="ps4_iznajmljivanje_akcije.css" type="text/css"/>
	</head>

	<body>
	<div id="container_svega">
		<div id="container">
			<div id="gornji">
					<h2 class="gornji_ispis_tekst" title="Iznajmljivanje sony playstation 4 Beograd - 062/182-1998" >Dobrodosli! Iznajmljivanje PS4 - 062/182-19-98</h2>
					<span class="drustvene" id="span_1"><a href="https://www.facebook.com/Iznajmljivanje-PS4-980795131983330/timeline/" title="Pratite nas i na fejsbuku - PS4 iznajmljivanje Beograd!"><img src="Mihailo sajt slike/logo/face_mala.png"/></a></span>
					<span class="drustvene" id="span_2"><a href="https://www.facebook.com/Iznajmljivanje-PS4-980795131983330/timeline/"  title="Pratite nas i na instagramu - PS4 iznajmljivanje Beograd!"><img src="Mihailo sajt slike/logo/insta_mala.jpg"/></a></span>
			</div>
			<div id="menu">
				
					<a href="index.php" class="meni_a" title="Iznajmljivanje Sony Playstation 4 Index"><span class="meni_span" id="levi">Pocetna</span></a>
					<a href="ps4_iznajmljivanje_igrice.php" class="meni_a" title="Iznajmljivanje Sony Playstation 4 Igrice"><span class="meni_span">Igrice</span></a>
					<a href="ps4_iznajmljivanje_cenovnik.php" class="meni_a" title="Iznajmljivanje Sony Playstation 4 Cenovnik"><span class="meni_span">Cenovnik</span></a>
					<a href="ps4_iznajmljivanje_akcije.php" class="meni_a" title="Iznajmljivanje Sony Playstation 4 Akcije"><span class="meni_span"  id="aktivan">Akcije</span></a>
					<a href="ps4_iznajmljivanje_kontakt.php" class="meni_a" title="Iznajmljivanje Sony Playstation 4 Kontakt"><span class="meni_span">Kontakt</span></a>
				
			</div>
			
			<div id="container_sredina">
			
				<div id="container_slika">
				
						<div id="1"  class="slicica"><img src="Mihailo sajt slike/PS4-iznajmi-Beograd-soni4iznajmljivanje.rs_.jpg" height="100%" width="100%" alt="Iznajmljivanje sony4 Beograd"/></div>
						<div id="2"  class="slicica"><img src="Mihailo sajt slike/PES2016-Club-PS4 Iznajmljivanje.jpg" height="100%" width="100%" alt="PES 2016 iznajmljivanje PS4 Beograd"/></div>
						<div id="3"  class="slicica"><img src="Mihailo sajt slike/PS4_Iznajmljivanje_beograd_soni4_iznajmljivanje.jpg" height="100%" width="100%" alt="Najbolje igrice za iznajmljivanje za Sony Playstation 4 PS4iznajmljivanje.rs"/></div>
						<div id="4"  class="slicica"><img src="Mihailo sajt slike/Sony-4-iznajmljivanje-Beograd.jpg" height="100%" width="100%" alt="Iznajmljivanje PS4 Beograd"/></div>
						<div id="5"  class="slicica"><img src="Mihailo sajt slike/PlayStation4-sony 4 iznajmljivanje.jpg" height="100%" width="100%" alt="Igrice za sony4 | PS4 iznajmljivanje"/></div>
					
				</div>
				<div class="slika_preko">
				
						
					<div id="slika_preko_1" class="klasa_slika_preko">
						<h2 class="ispis_slika_preko" title="Popusti i akcije na Sony 4 iznajmljivanje!">Bonusi i akcije!</h2></br></br></br>
						<p class="ispis_p_slika_preko">AKCIJA 7 DANA - 6200rsd! Besplatna dostava, 2 po izboru, ostale po 100rsd dnevno. BONUS - Igrica! samo na www.ps4iznajmljivanje.rs!</p></br></br></br></br>
						<a href="ps4_iznajmljivanje_akcije.php" title="Detaljnije o akciji na PS4 iznajmljivanje Beograd" class="span"><span class="detaljnije"><i>Detaljnije ovde..</i></span></a>
					</div>
					
					<div id="slika_preko_2" class="klasa_slika_preko">
						<h2 class="ispis_slika_preko" title="FIFA 16 i PES 16 samo na PS4 iznajmljivanje Beograd!">Nova FIFA 16 i PES 16 su stigle!</h2></br></br>
						<p class="ispis_p_slika_preko">Pre samo nekoliko dana izasle su u prodaju, a vec se nalaze u nasoj kolekciji igara.
						Nedozvolite da neko do njih stigne pre Vas, iznajmite PS4 konzolu pozivom na broj </br>062/182-1998!</p></br></br>
						<a href="ps4_iznajmljivanje_igrice.php" class="span" title="Deljnije o igrama za Sony 4 na ps4iznajmljivanje.rs/igre"><span class="detaljnije"><i>Detaljnije ovde..</i></span></a>
					</div>

					<div id="slika_preko_3" class="klasa_slika_preko">
						<h2 class="ispis_slika_preko" title="Ogromna kolekcija igara za SONY 4 | Iznajmljivanje PS4 Beograd!">Ogromna kolekcija od cak 20 igara!</h2></br></br>
						<p class="ispis_p_slika_preko">Pri svakom iznajmljivanju mozete uzeti 2 igrica koje zelite! Ne zaboravite da imamo jednu od najvecih kolekcija  za PS4.</br> Iznajmljivanje na broj 062/182-1998!</p></br></br>
						<a href="ps4_iznajmljivanje_igrice.php" title="Deljnije o igrama za Sony 4 na ps4iznajmljivanje.rs/igre" class="span"><span class="detaljnije"><i>Detaljnije ovde..</i></span></a>
					</div>
					
					<div id="slika_preko_4" class="klasa_slika_preko">
						<h2 class="ispis_slika_preko" title="Akcije za iznajmljivanje sony 4 na PS4 iznajmljivanje Beograd!">Svakog radnog dana!</h2></br></br>
						<p class="ispis_p_slika_preko">Na Vracaru I na Starom gradu mozete iznajmiti SONY na sat, uz besplatno dostavu i 
										cenu od 150rsd po satu, maksimalno vreme iznajmljivanja je sest sati, sa zavrsnim terminom u 20h.</p></br></br>
						<a href="ps4_iznajmljivanje_akcije.php" title="Detaljnije o akciji na PS4 iznajmljivanje Beograd" class="span"><span class="detaljnije"><i>Detaljnije ovde..</i></span></a>
					
					</div>
					<div id="slika_preko_5" class="klasa_slika_preko">
						<h2 class="ispis_slika_preko" title="Novi PS4 na iznajmljivanje Beograd!">Pravila iznajmljivanja!</h2></br></br>
						<p class="ispis_p_slika_preko">Pri svakom iznajmljivanju morate ostaviti licnu kartu, sony povezujemo mi, uveravamo se da je isti ispravan. U slucaju bilo kakvog kvara 
						stetu moramo naplatiti. Iznajmljivanje moguce i putem facebook-a!</p></br></br>
						<a href="index.php" class="span" title="Pravila iznajmljivanja Sony 4 Beograd"><span class="detaljnije"><i>Detaljnije ovde..</i></span></a>
					
					</div>
				</div>
				
				<div id="container_menjac">
						<div id='menjaci_drzac'>
							<a onclick="menjac(1);" class="a_menjac"><span class='menjac' id='menjac1'></span></a>
							<a onclick="menjac(2);" class="a_menjac"><span class='menjac' id='menjac2'></span></a>
							<a onclick="menjac(3);" class="a_menjac"><span class='menjac' id='menjac3'></span></a>
							<a onclick="menjac(4);" class="a_menjac"><span class='menjac' id='menjac4'></span></a>
							<a onclick="menjac(5);" class="a_menjac"><span class='menjac' id='menjac5'></span></a>
						</div>
					</div>
					
				<div id="container_sredina_trizanci">
					<div class="trizanci">
							<div class="trizanci_naslov_omotac">
								<div class="trizanci_krivi"><h1 class="trizanci_naslov" title="Sony 4 iznajmljivanje akcije i popusti na ps4iznajmljivanje.rs">Akcije | Bonusi</h1></div>
							</div>
							<p class="trizanci_paragraf"></br><b>Akcije i Bonusi</b> se sastoje u tome, sto uz najpovoljnije uslove mozete iznajmiti SONY playstation samo na <b>ps4iznajmljivanje.rs!</b></br></br>
							<b>Akcije </b>su nedeljne, a bonusi dnevni! Ne zaboravite da ocenite najbolje akcije, Vas <b>PS4 Iznajmljivanje Beograd.</b></p></br><hr></br>
							
							<?php
							include("konekcija.inc");
							$upit="SELECT * FROM akcije";
							$rez=mysql_query($upit) or die(mysql_error());
							
							while($r=mysql_fetch_array($rez))
							{
								if(isset($_SESSION['id']))
								{
									if($_SESSION['id']==$r['id'])
									{
										echo("<p class=\"trizanci_paragraf\">");
											echo("<b>".$r['tip_akcije']."</b> ".$r['tekst']."<img src='Mihailo sajt slike/akcija_stiklir.png' id='nisam_tu'/></br></br>");
											echo("</p>");
									}
									else
									{
										echo("<p class=\"trizanci_paragraf\">");
											echo("<b>".$r['tip_akcije']."</b> ".$r['tekst']."<a title='Like za akciju PS4 iznajmljivanje' onclick='return nestati(".$r['id'].");' class='".$r['id']."'><img src='Mihailo sajt slike/akcije_like2.png' alt='Like_za_akciju_PS4_iznajmljivanje' class='like'/></a>
											<a title='dislike za akciju PS4 iznajmljivanje' onclick='return nestati2(".$r['id'].");' class='".$r['id']."'><img src='Mihailo sajt slike/akcije_dislike.png' alt='dislike_za_akciju_PS4_iznajmljivanje' class='dislike'/></a>
											<img src='Mihailo sajt slike/akcija_stiklir.png' id='nisam_tu' alt='Stiklir Sony 4 Iznajmljivanje Beograd'/></br></br>");
									echo("</p>");
									}
								}
								else
								{
									echo("<p class=\"trizanci_paragraf\">");
											echo("<b>".$r['tip_akcije']."</b> ".$r['tekst']."<a title='Like za akciju PS4 iznajmljivanje' onclick='return nestati(".$r['id'].");' class='".$r['id']."'><img src='Mihailo sajt slike/akcije_like2.png' alt='Like za akciju PS4 iznajmljivanje' class='like'/></a>
											<a title='dislike za akciju PS4 iznajmljivanje' onclick='return nestati2(".$r['id'].");' class='".$r['id']."'><img src='Mihailo sajt slike/akcije_dislike.png' alt='dislike za akciju PS4 iznajmljivanje' class='dislike'/></a>
											<img src='Mihailo sajt slike/akcija_stiklir.png' id='nisam_tu' alt='Stiklir Sony 4 Iznajmljivanje Beograd'/></br></br>");
									echo("</p>");
								}
							}
							mysql_close();
						?>
								
						
						
					</div>
					<div class="trizanci">
					
						<div class="trizanci_naslov_omotac">
							<div class="trizanci_krivi"><h1 class="trizanci_naslov" title="Dnevne akcija za iznajmljivanje Sony 4">Dnevne Akcije</h1></div>
						</div>
							<?php
								include("konekcija.inc");
								$h="SELECT * FROM dnevne";
								$fin=mysql_query($h);
								if(mysql_num_rows($fin) > 0)
								{
									while($g=mysql_fetch_array($fin))
									{
										echo("<p class=\"trizanci_paragraf\">");
											echo("<b>".$g['tip']."</b>".$g['tekst']."<a title='Like za akciju' onclick='return nestati(".$g['id'].");' class='".$g['id']."'><img src='Mihailo sajt slike/akcije_like2.png' alt='stiklir_za_akciju' class='like'/></a>
											<a title='Dislike za akciju' onclick='return nestati(".$g['id'].");' class='".$g['id']."'><img src='Mihailo sajt slike/akcije_dislike.png' alt='stiklir_za_akciju' class='dislike'/></a>
											<img src='Mihailo sajt slike/akcija_stiklir.png' id='nisam_tu'/></br></br>");
										echo("</p>");
									}
								}
								else
								{
									echo("<p class=\"trizanci_paragraf\">Trenutno nema dnevnih akcija za PS4 konzole. Pratite nas svakodnevno i ostvarite popuste i do <b>50%</b>. :)</p></br></br>");
								}
							?>
						
					</div>
					
					
				</div>
				
			</div>
		</div>
		<div id="footer">
			<p class="footer_ispis">Copyright © <?php echo date("Y");?> Nikola Mihajlovic | Soni 4 Iznajmljivanje. All rights reserved.</p>
		</div>
	</div>
		
	</body>
</html>