﻿<?php session_start();
	if(isset($_GET['id']))
	{
		$id=$_GET['id'];
		include("konekcija.inc");
		$upit="SELECT * FROM akcije WHERE id=".$id;
		$rez=mysql_query($upit) or die("Error: ".mysql_error());
		$x=mysql_fetch_array($rez);
		$broj=$x['dislajkovi'];
		
		$broj=$broj+1;
		
		
		$zapit="UPDATE akcije SET dislajkovi=".$broj." WHERE id=".$id;
		if(mysql_query($zapit))
		{
			$_SESSION['id']=$id;
		}
		else
		{
			echo("Error: ".mysql_error());
		}
		mysql_close();
	}

?>