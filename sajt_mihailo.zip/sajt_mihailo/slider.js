﻿
					function nestati(id)
					{
						var nestaje=parseInt(id);
						
						$.ajax({
							
							type:"GET",
							url:"broj_lajkova.php?id="+nestaje,
							
							success: function()
							{
								$('.trizanci_paragraf > .'+nestaje).hide(500);
							}
						});
					}
					function nestati2(id)
					{
						var nestaje=parseInt(id);
						
						$.ajax({
							
							type:"GET",
							url:"broj_dislike.php?id="+nestaje,
							
							success: function()
							{
								$('.trizanci_paragraf > .'+nestaje).hide(500);
							}
						});
					}