﻿function provera_admin()
{
	var forma=document.getElementById("forma_unesi_admina");
	var uloga=document.getElementById("tbUloga").value;
	var username=document.getElementById("tbUser").value;
	var password=document.getElementById("tbPass").value;
	alert(uloga);
	alert(username);
	alert(password);
	if(uloga=="")
	{
		alert("Moras uneti ulogu!");
		return false;
	}
	else if(username=="")
	{
		alert("Moras uneti username");
		return false;
	}
	else if(password=="")
	{
		alert("Moras uneti password");
		return false;
	}
	else
	{
		return true;
	}
}
function provera_akcije()
{
	var tip=document.getElementById("tbTip").value;
	var tekst=document.getElementById("tbTekst").value;
	
	if(tip=="")
	{
		alert("Moras uneti tip");
		return false;
	}
	else if(tekst=="")
	{
		alert("Moras uneti tekst");
		return false;
	}
	else
	{
		return true;
	}
}
function provera_dnevne()
{
	var tip=document.getElementById("tbTipDnevnog").value;
	var tekst=document.getElementById("tbTekstDnevnog").value;
	
	if(tip=="")
	{
		alert("Moras uneti tip");
		return false;
	}
	else if(tekst=="")
	{
		alert("Moras uneti tekst");
		return false;
	}
	else
	{
		return true;
	}
}
function provera_igrice()
{
	var ime=document.getElementById("tbIme").value;
	var file=document.getElementById("file").value;
	
	if(ime=="")
	{
		alert("Moras uneti ime ");
		return false;
	}
	else if(file=="")
	{
		alert("Moras uneti file slike");
		return false;
	}
	else{
		return true;
	}
}
function provera_igrice_prodaja()
{
	var ime=document.getElementById("tbImeProdaja").value;
	var file=document.getElementById("fileProdaja").value;
	
	if(ime=="")
	{
		alert("Moras uneti ime ");
		return false;
	}
	else if(file=="")
	{
		alert("Moras uneti file slike");
		return false;
	}
	else
	{
		return true;
	}
}
function provera_cena()
{
	var sati=document.getElementById("tbSati").value;
	var cena=document.getElementById("tbCena").value;
	var tip=document.getElementById("ddlTip").value;
	
	if(sati=="")
	{
		alert("Moras broj sati za cenu ");
		return false;
	}
	if(cena=="")
	{
		alert("Moras uneti cenu ");
		return false;
	}
	if(tip==0)
	{
		alert("Moras uneti tip");
		return false;
	}
}