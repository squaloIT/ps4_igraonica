﻿<?php session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
	<head>
		<title> PS4 Iznajmljivanje Beograd | Sony4 Iznajmljivanje 062/182-1998</title>
		<meta http-equiv="Content-Type" content="text/html"; charset="UTF-8"> 
	
		<meta name="author" content="Nikola Mihajlovic"/ >
		<link rel="shortcut icon" href="Mihailo sajt slike/logo/favicon.jpg" type="image/x-icon">
		<link href='https://fonts.googleapis.com/css?family=Noto+Serif' rel='stylesheet' type='text/css'>
		<link rel="icon" href="Mihailo sajt slike/logo/favicon.jpg" type="image/x-icon">
		
		<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
		
		<script src="//code.jquery.com/jquery-1.10.2.js"></script>
		<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
			
		<link rel="stylesheet" href="admin.css" type="text/css"/>
		
		<script src="admin_provere.js"></script>
	</head>

	<body>
	
		<div id="container">
			<div id="gornji">
					<h2 class="gornji_ispis_tekst" title="Iznajmljivanje sony playstation 4 Beograd - 062/182-1998" >Iznajmljivanje PS4 konzola! 062/182-1998</h2>
					<span class="drustvene" id="span_1"><a href="https://www.facebook.com/Iznajmljivanje-PS4-980795131983330/timeline/" title="Pratite nas i na fejsbuku!"><img src="Mihailo sajt slike/logo/face_mala.png"/></a></span>
					<span class="drustvene" id="span_2"><a href="https://www.facebook.com/Iznajmljivanje-PS4-980795131983330/timeline/"  title="Pratite nas i na instagramu!"><img src="Mihailo sajt slike/logo/insta_mala.jpg"/></a></span>
			</div>
			<?php	
		if(isset($_REQUEST['btnUnesiAdmina']))
		{
			
			include("konekcija.inc");
			$user=$_REQUEST['tbUsername'];
			echo($user);
			$pass=$_REQUEST['tbPassword'];
			echo($pass);
			$user=addslashes($user);
			$pass=addslashes($pass);
			$passMD5=md5($pass);
			$zapit="SELECT * FROM admin WHERE username='".$user."' AND password='".$passMD5."'";
			$stiglo=mysql_query($zapit) or die(mysql_error());
			
			$niz=mysql_fetch_array($stiglo);
			
			if(empty($niz))
			{
				echo(mysql_error());
			}
			else
			{
				$_SESSION['admin']=$user;
				echo($_SESSION['admin']);
			}
			mysql_close();
			
		}
	
	?>
			<div id="menu">
					<a href="index.php" class="meni_a" title="Iznajmljivanje Sony Playstation 4 Index"><span class="meni_span" id="aktivan">Pocetna</span></a>
					<a href="ps4_iznajmljivanje_igrice.php" class="meni_a" title="Iznajmljivanje Sony Playstation 4 Igrice"><span class="meni_span">Igrice</span></a>
					<a href="ps4_iznajmljivanje_cenovnik.php" class="meni_a" title="Iznajmljivanje Sony Playstation 4 Cenovnik"><span class="meni_span">Cenovnik</span></a>
					<a href="ps4_iznajmljivanje_akcije.php" class="meni_a" title="Iznajmljivanje Sony Playstation 4 Akcije"><span class="meni_span">Akcije</span></a>
					<a href="ps4_iznajmljivanje_kontakt.php" class="meni_a" title="Iznajmljivanje Sony Playstation 4 Kontakt"><span class="meni_span">Kontakt</span></a>
			</div>
			
			<?php
				
				if(isset($_SESSION['admin']))
				{
					echo($_SESSION['admin']);
					echo("<form action='logout.php' method='POST' name='forma_unesi' id='forma_unesi' enctype='multipart/form-data' >
					<input type='submit' name='btnLogout' value='Log out'/></form></br>");
					echo("<div class='container_ispis'>
								<h2 class='ispis_naslov'>Unesi admina: </h2>
								<form action='unesi_admina.php' method='POST' name='forma_unesi_admina' id='forma_unesi_admina' enctype='multipart/form-data' onSubmit='return provera_admin();'>
									<table border='1px'>
										<tr><th>Uloga</th><th>Username</th><th>Password</th><th></th></tr>
										<tr><td><input type='text' name='tbUloga' id='tbUloga'/></td><td><input type='text' name='tbUser' id='tbUser'/></td>
										<td><input type='password' name='tbPass' id='tbPass'/></td><td><input type='submit' name='btnUnesiAdmina'/></td></tr>
									</table>
								</form>
						
					</div>");
					include("konekcija.inc");
					$query="SELECT * FROM admin";
					$rez=mysql_query($query);
					echo("<div class='container_ispis'>
								<h2 class='ispis_naslov'>Izbrisi admina: </h2>
								
									<table border='1px'>
										<tr><th>ID</th><th>Uloga</th><th>Username</th><th>Password</th><th>Klik za brisanje</th></tr>");
										while($r=mysql_fetch_array($rez))
										{
											echo("
											<tr><td>".$r['id']."</td><td>".$r['uloga']."</td>
											<td>".$r['username']."</td><td>".$r['password']."</td>
											<td><a href='izbrisi.php?id=".$r['id']."' title='Izbrisi Admina'>Izbrisi</a></td></tr>");
										}
										echo("
									</table>
								</form>
						
					</div>");
					
					#--------------------------------------------------------------------------------------------------------------------------------------
					
					
					echo("<div class='container_ispis'>
								<h2 class='ispis_naslov'>Unesi akciju: </h2>
								<form action='unesi_admina.php' method='POST' name='forma_unesi_admina' enctype='multipart/form-data' onSubmit='return provera_akcije();'>
									<table border='1px'>
										<tr><th>Tip</th><th>Tekst</th><th></th></tr>
										<tr><td><input type='text' name='tbTip' id='tbTip'/></td>
										<td><textarea cols='30' rows='5' name='tbTekst' id='tbTekst'></textarea></td>
										<td><input type='submit' name='btnUnesiAkciju'/></td></tr>
									</table>
								</form>
						
					</div>");
					echo("<div class='container_ispis'>
								<h2 class='ispis_naslov'>Izbrisi akciju: </h2>
								
									<table border='1px'>");
									
									$pitam="SELECT * FROM akcije";
									$rez2=mysql_query($pitam);
									echo("<tr><th>Tip</th><th>Tekst</th><th>Broj lajkova</th><th>Broj dislajkova</th><th></th></tr>");
									while($t=mysql_fetch_array($rez2))
									{
										echo("
										
										<tr><td>".$t['tip_akcije']."</td>
										<td>".$t['tekst']."</td>
										<td>".$t['lajkovi']."</td>
										<td>".$t['dislajkovi']."</td>
										<td><a href='izbrisi.php?id_akcije=".$t['id']."' title='Izbrisi Akciju'>Izbrisi</a></td></tr>
										");
									}
									
									
									echo("</table>
								
						
					</div>");
					
					#--------------------------------------------------------------------------------------------------------------------------------------
					
					
					echo("
						<div class='container_ispis'>
							<h2 class='ispis_naslov'>Unesi dnevnu akciju: </h2>
							<form action='unesi_admina.php' method='POST' enctype='multipart/form-data' onSubmit='return provera_dnevne();'>
								<table border='1px'>
									<tr><th>Tip</th><th>Tekst</th><th></th></tr>
									<tr><td><input type='text' name='tbTipDnevnog' id='tbTipDnevnog'/></td>
									<td><textarea cols='30' rows='5' name='tbTekstDnevnog' id='tbTekstDnevnog'></textarea></td>
									<td><input type='submit' name='btnUnesiDnevni'/></td></tr>
								</table>
							</form>
					</div>");
					
						echo("
						<div class='container_ispis'>
							<h2 class='ispis_naslov'>Unesi dnevnu akciju: </h2>
							
								");
									
									$pez="SELECT * FROM dnevne";
									$rezzz=mysql_query($pez);
									if(mysql_num_rows($rezzz) == 0)
									{
										echo("<p class=\"trizanci_paragraf\">Trenutno nema dnevnih akcija za PS4 konzole. :)</p>");
									}
									else
									{
										echo("<table border='1px'>
																					<tr><th>Tip</th><th>Tekst</th><th></th></tr>");
										while($x=mysql_fetch_array($rezzz))
										{
											echo("
											<tr><td>".$x['tip']."</td>
											<td>".$x['tekst']."</td>
											<td><a href='izbrisi.php?id_dnevne=".$x['id']."' title='Izbrisi Dnevnu Akciju'>Izbrisi</a></td></tr>
											");
										}
										echo("</table>");
									}
								
							
					echo("</div>");
					
					#--------------------------------------------------------------------------------------------------------------------------------------
					
					
					echo("
						<div class='container_ispis'>
							<h2 class='ispis_naslov'>Unesi novu igricu za iznajmljivanje: </h2>
							<form action='unesi_admina.php' method='POST' enctype='multipart/form-data' onSubmit='return provera_igrice();'>
								<table border='1px'>
									<tr><th>Ime</th><th>Opis</th><th>File slike: </th><th></th></tr>
									<tr><td><input type='text' name='tbIme' id='tbIme'/></td>
									<td><input type='file' name='file' id='file'/></td>
									<td><input type='submit' name='btnUnesiIgricu'/></td></tr>
								</table>
							</form>
					</div>");
					
					
				
					$tyt="SELECT * FROM igrice";
					$rez22=mysql_query($tyt) or die("Error: ".mysql_error());
					echo("
					<div class='container_ispis'>
							<h2 class='ispis_naslov'>Izbrisi igricu za iznajmljivanje: </h2>
							<table border='1px'><tr><th>Ime: </th><th></th></tr>");
							
					while($v=mysql_fetch_array($rez22))
					{
						echo("<tr><td>".$v['ime']."</td><td><a href='izbrisi.php?id_igrice=".$v['id']."' title='Izbrisi igricu'>Izbrisi</a></td></tr>");
					}
				
					
					echo("</table>");
					echo("</div>");
					
					#--------------------------------------------------------------------------------------------------------------------------------------
					
						echo("
						<div class='container_ispis'>
							<h2 class='ispis_naslov'>Unesi novu igricu za prodaju: </h2>
							<form action='unesi_admina.php' method='POST' enctype='multipart/form-data' onSubmit='return provera_igrice_prodaja();'>
								<table border='1px'>
									<tr><th>Ime</th><th>Opis</th><th>File slike: </th><th></th></tr>
									<tr><td><input type='text' name='tbImeProdaja' id='tbImeProdaja'/></td>
									<td><input type='file' name='fileProdaja' id='fileProdaja'/></td>
									<td><input type='submit' name='btnUnesiIgricuProdaja'/></td></tr>
								</table>
							</form>
					</div>");
					
					
					$tyty="SELECT * FROM igrice_prodaja";
					$rez223=mysql_query($tyty) or die("Error: ".mysql_error());
					echo("
					<div class='container_ispis'>
							<h2 class='ispis_naslov'>Izbrisi igricu za prodaju: </h2>
							<table border='1px'><tr><th>Ime: </th><th></th></tr>");
							
					while($v2=mysql_fetch_array($rez223))
					{
						echo("<tr><td>".$v2['ime']."</td><td><a href='izbrisi.php?id_igrice_prodaja=".$v2['id']."' title='Izbrisi igricu'>Izbrisi</a></td></tr>");
					}
				
					
					echo("</table>");
					echo("</div>");
					
					#--------------------------------------------------------------------------------------------------------------------------------------
					
					
					echo("<div class='container_ispis'>
					<h2 class='ispis_naslov'>Unesi novu cenu u cenovnik: (Pored cene se pisu eventualni bonusi) </h2>
					<form action='unesi_admina.php' method='POST' enctype='multipart/form-data' onSubmit='return provera_cena();'>
								<table border='1px'>
									<tr><th>Sati: </th><th>Cena: </th><th>Tip: </th><th></th></tr>
									<tr><td><input type='text' name='tbSati' id='tbSati'/></td>
									<td><input type='text' name='tbCena' id='tbCena'/></textarea></td>
									<td><select name='ddlTip' id='ddlTip'>
									<option value='0'>Izaberi</option>
									<option value='1'>2 dzoistika</option>
									<option value='2'>4 dzoistika</option>
									<option value='3'>Cena na sat</option></select></td>
									<td><input type='submit' name='btnUnesiCenu'/></td></tr>
								</table>
							</form>
						</div>");
						
						
					$tot="SELECT * FROM cenovnik";
					$rez23=mysql_query($tot) or die("Error: ".mysql_error());
					$tip='';
					echo("
					<div class='container_ispis'>
							<h2 class='ispis_naslov'>Izbrisi Cenu: </h2>
							<table border='1px'><tr><th>Sati: </th><th>Cena: </th><th>Tip: </th><th></th></tr>");
							
					while($p=mysql_fetch_array($rez23))
					{
						if($p['tip']==1)
						{
							$tip='2 dzoistika';
						}
						if($p['tip']==2)
						{
							$tip='4 dzoistika';
						}
						if($p['tip']==3)
						{
							$tip='Cena po satu';
						}
						echo("<tr><td>".$p['sati']."</td><td>".$p['cena']."</td><td>".$tip."</td><td><a href='izbrisi.php?id_cene=".$p['id']."' title='Izbrisi cenu'>Izbrisi</a></td></tr>");
					}
					mysql_close();
					
					echo("</table>");
				}
				else
				{
					echo("<div class='container_ispis'>
								<h2 class='ispis_naslov'>Log in admin: </h2>
								<form action='ps4_iznajmljivanje_admin.php' method='POST' name='forma_unesi_admina' enctype='multipart/form-data' >
									<table border='1px'>
										<tr><th>Username</th><th>Password</th><th></th></tr>
										<tr></td><td><input type='text' name='tbUsername' id='tbUsername'/></td>
										<td><input type='password' name='tbPassword' id='tbPassword'/></td><td><input type='submit' name='btnUnesiAdmina' value='Provera'/></td></tr>
									</table>
								</form>
						
					</div>");
				}
				
			?>
				
		</div>

		</div>
		<div id="footer">
			<p class="footer_ispis">Copyright © <?php echo date("Y");?> Nikola Mihajlovic | Soni 4 Iznajmljivanje. All rights reserved.</p>
		</div>
	</body>
</html>