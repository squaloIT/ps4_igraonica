﻿$(document).ready(function()
				{
					$('.menjac').click(function()
					{
							$('.menjac').css('background-color','#FFF');
							$(this).css('background-color','#33CCFF');
					});
				
				
});
function menjac(id)
{
	
	if(id==1)
	{
		$("#container_slika div").hide("fade",500);
		$("#container_slika #1").show("fade",500);
		
		$(".slika_preko div").hide("fade",500);
		$(".slika_preko #slika_preko_1").show("fade",1000);
		
		
		
		
	}
	else if(id==2)
	{
		$("#container_slika div").hide("fade",500);
		$("#container_slika #2").show("fade",500);
		
		$(".slika_preko div").hide("fade",500);
		$(".slika_preko #slika_preko_2").show("fade",500);
		
		
		
	}
	else if(id==3)
	{
		$("#container_slika div").hide("fade",500);
		$("#container_slika #3").show("fade",500);
		
		$(".slika_preko div").hide("fade",500);
		$(".slika_preko #slika_preko_3").show("fade",500);
		
	
	}
	
	else if(id==4)
	{
		$("#container_slika div").hide("fade",500);
		$("#container_slika #4").show("fade",500);
		
		$(".slika_preko div").hide("fade",500);
		$(".slika_preko #slika_preko_4").show("fade",500);
		
	
	
	}
	
	else if(id==5)
	{
		$("#container_slika div").hide("fade",500);
		$("#container_slika #5").show("fade",500);
		
		$(".slika_preko div").hide("fade",500);
		$(".slika_preko #slika_preko_5").show("fade",500);
		
		
		
	}
}
