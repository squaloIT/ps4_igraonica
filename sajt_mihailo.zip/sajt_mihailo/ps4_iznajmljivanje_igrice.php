﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
	<head>
		<title> PS4 Iznajmljivanje Beograd | Sony4 Igre 062/182-1998</title>
		<meta http-equiv="Content-Type" content="text/html"; charset="UTF-8" /> 
		<meta name="description" content="Iznajmljivanje Sony4 Beograd - najpopularnije igre po najboljim cenama za iznajmljivanje! Iznajmljivanje PS4 Beograd!" />
		<meta name="keywords" content="iznajmljivanje sony4, ps4 iznajmljivanje, ps4 iznajmljivanje Beograd, iznajmljivanje sony4 Beograd, ps4 igrice iznajmljivanje"  lang="sr" xml:lang="sr" />
		<meta name="author" content="Nikola Mihajlovic" />
		<meta name="robots" content="all" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		
		
			<meta property="og:title" content="PS4 Iznajmljivanje Igrice | Beograd!" />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="http://www.ps4iznajmljivanje.rs/ps4_iznajmljivanje_igrice.php" />
        <meta property="og:image" content="http://www.ps4iznajmljivanje.rs/Mihailo%20sajt%20slike/ps4_iznajmljivanje_za_fb.png" /> 
		<meta property="article:author" content="https://www.facebook.com/nikola.a.mihajlovic" />
        <meta property="og:site_name" content="PS4 Iznajmljivanje Beograd" />
        <meta property="og:description" content="Sony 4 Iznajmljivanje Beograd 062-182-1998. Najpopularnije igre koje dobijate besplatno, po najpovoljnijim cenama u Beogradu. Dostava besplatna! " />
		
	
		<link href='https://fonts.googleapis.com/css?family=Noto+Serif' rel='stylesheet' type='text/css'>
		<link rel="icon" href="Mihailo sajt slike/logo/favicon.jpg" type="image/x-icon">
		
			<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
		
		<script src="//code.jquery.com/jquery-1.10.2.js"></script>
		<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
		
			<script type="text/javascript" src="menjac.js"></script>
		<link rel="stylesheet" type="text/css" href="igrice.css"/>
	</head>

	<body>
		<div id="container">
			<div id="gornji">
					<h2 class="gornji_ispis_tekst" title="Iznajmljivanje sony playstation 4 Beograd - 062/182-1998" >Dobrodosli! Iznajmljivanje PS4 - 062/182-19-98</h2>
					<span class="drustvene" id="span_1"><a href="https://www.facebook.com/Iznajmljivanje-PS4-980795131983330/timeline/" title="Pratite nas i na fejsbuku - PS4 iznajmljivanje Beograd!"><img src="Mihailo sajt slike/logo/face_mala.png"/></a></span>
					<span class="drustvene" id="span_2"><a href="https://www.facebook.com/Iznajmljivanje-PS4-980795131983330/timeline/"  title="Pratite nas i na instagramu - PS4 iznajmljivanje Beograd!"><img src="Mihailo sajt slike/logo/insta_mala.jpg"/></a></span>
			</div>
			<div id="menu">
				
					<a href="index.php" class="meni_a" title="Iznajmljivanje Sony Playstation 4 Index"><span class="meni_span" id="aktivan">Pocetna</span></a>
					<a href="ps4_iznajmljivanje_igrice.php" class="meni_a" title="Iznajmljivanje Sony Playstation 4 Igrice"><span class="meni_span" id="aktivan2">Igrice</span></a>
					<a href="ps4_iznajmljivanje_cenovnik.php" title="Iznajmljivanje Sony Playstation 4 Cenovnik" class="meni_a"><span class="meni_span">Cenovnik</span></a>
					<a href="ps4_iznajmljivanje_akcije.php" class="meni_a" title="Iznajmljivanje Sony Playstation 4 Akcije"><span class="meni_span">Akcije</span></a>
					<a href="ps4_iznajmljivanje_kontakt.php" class="meni_a" title="Iznajmljivanje Sony Playstation 4 Kontakt"><span class="meni_span">Kontakt</span></a>
					
				
			</div>
			
			<div id="container_sredina">
			
				<div id="container_slika">
				
					<div id="1"  class="slicica"><img src="Mihailo sajt slike/PS4-iznajmi-Beograd-soni4iznajmljivanje.rs_.jpg" height="100%" width="100%" alt="Iznajmljivanje sony4 Beograd"/></div>
						<div id="2"  class="slicica"><img src="Mihailo sajt slike/PES2016-Club-PS4 Iznajmljivanje.jpg" height="100%" width="100%" alt="PES 2016 iznajmljivanje PS4 Beograd"/></div>
						<div id="3"  class="slicica"><img src="Mihailo sajt slike/PS4_Iznajmljivanje_beograd_soni4_iznajmljivanje.jpg" height="100%" width="100%" alt="Najbolje igrice za iznajmljivanje za Sony Playstation 4 PS4iznajmljivanje.rs"/></div>
						<div id="4"  class="slicica"><img src="Mihailo sajt slike/Sony-4-iznajmljivanje-Beograd.jpg" height="100%" width="100%" alt="Iznajmljivanje PS4 Beograd"/></div>
						<div id="5"  class="slicica"><img src="Mihailo sajt slike/PlayStation4-sony 4 iznajmljivanje.jpg" height="100%" width="100%" alt="Igrice za sony4 | PS4 iznajmljivanje"/></div>
					
				</div>
				<div class="slika_preko">
				
					
					<div id="slika_preko_1" class="klasa_slika_preko">
						<h2 class="ispis_slika_preko" title="Popusti i akcije na Sony 4 iznajmljivanje!">Bonusi i akcije!</h2></br></br></br>
						<p class="ispis_p_slika_preko">AKCIJA 7 DANA - 6200rsd! Besplatna dostava, 2 po izboru, ostale po 100rsd dnevno. BONUS - Igrica! samo na www.ps4iznajmljivanje.rs!</p></br></br></br></br>
						<a href="ps4_iznajmljivanje_akcije.php" title="Detaljnije o akciji na PS4 iznajmljivanje Beograd" class="span"><span class="detaljnije"><i>Detaljnije ovde..</i></span></a>
					</div>
					
					<div id="slika_preko_2" class="klasa_slika_preko">
						<h2 class="ispis_slika_preko" title="FIFA 16 i PES 16 samo na PS4 iznajmljivanje Beograd!">Nova FIFA 16 i PES 16 su stigle!</h2></br></br>
						<p class="ispis_p_slika_preko">Pre samo nekoliko dana izasle su u prodaju, a vec se nalaze u nasoj kolekciji igara.
						Nedozvolite da neko do njih stigne pre Vas, iznajmite PS4 konzolu pozivom na broj </br>062/182-1998!</p></br></br>
						<a href="ps4_iznajmljivanje_igrice.php" class="span" title="Deljnije o igrama za Sony 4 na ps4iznajmljivanje.rs/igre"><span class="detaljnije"><i>Detaljnije ovde..</i></span></a>
					</div>

					<div id="slika_preko_3" class="klasa_slika_preko">
						<h2 class="ispis_slika_preko" title="Ogromna kolekcija igara za SONY 4 | Iznajmljivanje PS4 Beograd!">Ogromna kolekcija od cak 20 igara!</h2></br></br>
						<p class="ispis_p_slika_preko">Pri svakom iznajmljivanju mozete uzeti 2 igrica koje zelite! Ne zaboravite da imamo jednu od najvecih kolekcija  za PS4.</br> Iznajmljivanje na broj 062/182-1998!</p></br></br>
						<a href="ps4_iznajmljivanje_igrice.php" title="Deljnije o igrama za Sony 4 na ps4iznajmljivanje.rs/igre" class="span"><span class="detaljnije"><i>Detaljnije ovde..</i></span></a>
					</div>
					
					<div id="slika_preko_4" class="klasa_slika_preko">
						<h2 class="ispis_slika_preko" title="Akcije za iznajmljivanje sony 4 na PS4 iznajmljivanje Beograd!">Svakog radnog dana!</h2></br></br>
						<p class="ispis_p_slika_preko">Na Vracaru I na Starom gradu mozete iznajmiti SONY na sat, uz besplatno dostavu i 
										cenu od 150rsd po satu, maksimalno vreme iznajmljivanja je sest sati, sa zavrsnim terminom u 20h.</p></br></br>
						<a href="ps4_iznajmljivanje_akcije.php" title="Detaljnije o akciji na PS4 iznajmljivanje Beograd" class="span"><span class="detaljnije"><i>Detaljnije ovde..</i></span></a>
					
					</div>
					<div id="slika_preko_5" class="klasa_slika_preko">
						<h2 class="ispis_slika_preko" title="Novi PS4 na iznajmljivanje Beograd!">Pravila iznajmljivanja!</h2></br></br>
						<p class="ispis_p_slika_preko">Pri svakom iznajmljivanju morate ostaviti licnu kartu, sony povezujemo mi, uveravamo se da je isti ispravan. U slucaju bilo kakvog kvara 
						stetu moramo naplatiti. Iznajmljivanje moguce i putem facebook-a!</p></br></br>
						<a href="index.php" class="span" title="Pravila iznajmljivanja Sony 4 Beograd"><span class="detaljnije"><i>Detaljnije ovde..</i></span></a>
					
					</div>
					
				</div>
				<div id="container_menjac">
					<div id='menjaci_drzac'>
						<a onclick="menjac(1);" class="a_menjac"><span class='menjac' id='menjac1'></span></a>
						<a onclick="menjac(2);" class="a_menjac"><span class='menjac' id='menjac2'></span></a>
						<a onclick="menjac(3);" class="a_menjac"><span class='menjac' id='menjac3'></span></a>
						<a onclick="menjac(4);" class="a_menjac"><span class='menjac' id='menjac4'></span></a>
						<a onclick="menjac(5);" class="a_menjac"><span class='menjac' id='menjac5'></span></a>
					</div>
				</div>
			</div>
				<div class="container_igrice">
						<div class="trizanci_naslov_omotac">
							<div class="trizanci_krivi"><h1 class="naslov_ispis" title="PS4 igrice za iznajmljivanje Beograd">PS4 | Igrice | Iznajmljivanje</h1></div>
						</div>
						<p class="trizanci_paragraf">Prilikom svakog iznajmljivanja dobijate besplatno, 2 igrice, po Vasem izboru. Svaka sledeca igrica naplacuje se dodatnih 100rsd. <b>Ne zaboravite da Vas TV mora imati HDMI prikljucak
						kako bi povezivanje konzole bilo moguce.</b>
						Narucite Vasu konzolu pozivom na broj <b>062/182-1998</b>, ili putem facebook-a na <a href="https://www.facebook.com/profile.php?id=100010299372923&fref=ts" title="Facebook link za iznajmljivanje Sony Playstation 4">PS4 Iznajmljivanje</a>!</p>
					<?php
						include("konekcija.inc");
						$opit="SELECT * FROM igrice";
						$ryz=mysql_query($opit) or die("Duboko se izvinjavamo zbog ove greske! Pokusajte sa refreshovanjem strane, Vas PS4 iznajmljivanje.rs");
						if(mysql_num_rows($ryz)==0)
						{
							echo("<h2 class='trizanci_naslov'>Trenurno nema nijedna igrica na raspologanju. Posetite nas sajt PS4iznajmljivanje.rs i sutra! </h2>");
						}
						while($q=mysql_fetch_array($ryz))
						{
							echo("<div class=\"trizanci\">");
								echo("<h2 class=\"trizanci_naslov\" title='".$q['ime']." PS4 Iznajmljivanje SONY 4 Beograd'><i>".$q['ime']."</i></h2>");
								echo("<img src='".$q['putanja']."' width='100%' height='300px' alt=' ".$q['ime']." PS4 Iznajmljivanje SONY 4 Beograd' />"); 
								
							echo("</div>");
						}
							
								
						
							
							
					?>
					<p class="siroko">	
						asdasdasdasdaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
					</p>
				</div>
				<div class="container_igrice">
						<div class="trizanci_naslov_omotac">
							<div class="trizanci_krivi"><h1 class="naslov_ispis" title="PS4 igrice prodaja Beograd">PS4 | Igrice | Prodaja</h1></div>
						</div>
						<p class="trizanci_paragraf">Svaka od dole navedenih igara kosta 45€. Kupovinom vise od 3 dobija se 10% popusta.  
						Igrice mozete naruciti pozivom na broj <b>062/182-1998</b>, ili putem facebook-a na <a href="https://www.facebook.com/profile.php?id=100010299372923&fref=ts" title="Facebook link za iznajmljivanje Sony Playstation 4">PS4 Iznajmljivanje</a>!</p>
					<?php
						include("konekcija.inc");
						$opit="SELECT * FROM igrice_prodaja";
						$ryz=mysql_query($opit) or die("<p class=\"trizanci_paragraf\">Trenutno nema igrica koje su na prodaju, pozivom na broj <b>062/182-19-98</b> mozete naruciti igru koju zelite.</p>");
						if(mysql_num_rows($ryz)==0)
						{
							echo("<p class=\"trizanci_paragraf\">Trenutno nema igrica koje su na prodaju, pozivom na broj <b>062/182-19-98</b> mozete naruciti igru koju zelite.</p>");
						}
						while($q=mysql_fetch_array($ryz))
						{
							echo("<div class=\"trizanci\">");
								echo("<h2 class=\"trizanci_naslov\" title='".$q['ime']." PS4 Iznajmljivanje SONY 4 Beograd'><i>".$q['ime']."</i></h2>");
								echo("<img src='".$q['putanja']."' width='100%' height='300px' alt=' ".$q['ime']." PS4 Iznajmljivanje SONY 4 Beograd' />"); 
								
							echo("</div>");
						}
	
					?>
					<p class="siroko">	
						asdasdasdasdaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
					</p>
				</div>
						
					
			
		</div>
		
		<div id="footer">
			<p class="footer_ispis">Copyright © <?php echo date("Y");?> Nikola Mihajlovic | Soni 4 Iznajmljivanje. All rights reserved.</p>
		</div>
	</body>
</html>