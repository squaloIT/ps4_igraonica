﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
	<head>
		<title> PS4 Iznajmljivanje Beograd | Sony4 Iznajmljivanje 062/182-1998</title>
		<meta http-equiv="Content-Type" content="text/html"; charset="UTF-8" />		
		<meta name="description" content="Sony4 Iznajmljivanje Beograd 062-182-1998 - najpopularnije igre koje dobijate besplatno, po najpovoljnijim cenama u Beogradu! Iznajmljivanje PS4 Beograd!" />
		<meta name="keywords" content="iznajmi sony4, ps4 iznajmljivanje, ps4 iznajmljivanje Beograd, sony4 iznajmljivanje Beograd, sony4 beograd, sony playstation iznajmljivanje"  lang="sr" xml:lang="sr" />
		<meta name="robots" content="all" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<meta name="author" content="nikola.mihajlovic.26.13@ict.edu.rs" />
		
		
		<meta property="og:title" content="PS4 Iznajmljivanje | Beograd!" />
        <meta property="og:type" content="article" />
        <meta property="og:url" content="http://www.ps4iznajmljivanje.rs/index.php" />
        <meta property="og:image" content="http://www.ps4iznajmljivanje.rs/Mihailo%20sajt%20slike/ps4_iznajmljivanje_za_fb.png" /> 
		<meta property="article:author" content="https://www.facebook.com/nikola.a.mihajlovic" />
        <meta property="og:site_name" content="PS4 Iznajmljivanje Beograd" />
        <meta property="og:description" content="Sony 4 Iznajmljivanje Beograd 062-182-1998. Najpopularnije igre koje dobijate besplatno, po najpovoljnijim cenama u Beogradu. Dostava besplatna! " />
		
		<link rel="shortcut icon" href="http://www.mysite.com/favicon.ico" type="image/x-icon">
		<link href='https://fonts.googleapis.com/css?family=Noto+Serif' rel='stylesheet' type='text/css'>
		<link rel="icon" href="Mihailo sajt slike/logo/favicon.jpg" type="image/x-icon">
		
			<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
		
		<script src="//code.jquery.com/jquery-1.10.2.js"></script>
		<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
		
		
			<script type="text/javascript">
				$(document).ready(function()
				{
					$('.textForma').focus(function()
					{
						$(this).css('border',' 1px solid #349BFF');
					});
					$('#taTekst').focus(function()
					{
						$(this).css('border',' 1px solid #349BFF');
					});
				});
			</script>
			<script type="text/javascript" src="menjac.js"></script>
			<script type="text/javascript" src="proveraFormulara.js"></script>
		<link rel="stylesheet" href="kontakt.css" type="text/css"/>
	</head>

	<body>
		<div id="container">
			<div id="gornji">
					<h2 class="gornji_ispis_tekst" title="Iznajmljivanje sony playstation 4 Beograd - 062/182-1998" >Dobrodosli! Iznajmljivanje PS4 - 062/182-19-98</h2>
					<span class="drustvene" id="span_1"><a href="https://www.facebook.com/Iznajmljivanje-PS4-980795131983330/timeline/" title="Pratite nas i na fejsbuku - PS4 iznajmljivanje Beograd!"><img src="Mihailo sajt slike/logo/face_mala.png"/></a></span>
					<span class="drustvene" id="span_2"><a href="https://www.facebook.com/Iznajmljivanje-PS4-980795131983330/timeline/"  title="Pratite nas i na instagramu - PS4 iznajmljivanje Beograd!"><img src="Mihailo sajt slike/logo/insta_mala.jpg"/></a></span>
			</div>
			<div id="menu">
				
					<a href="index.php" class="meni_a" title="Iznajmljivanje Sony Playstation 4 Index"><span class="meni_span" id="aktivan">Pocetna</span></a>
					<a href="ps4_iznajmljivanje_igrice.php" class="meni_a" title="Iznajmljivanje Sony Playstation 4 Igrice"><span class="meni_span">Igrice</span></a>
					<a href="ps4_iznajmljivanje_cenovnik.php" title="Iznajmljivanje Sony Playstation 4 Cenovnik" class="meni_a"><span class="meni_span">Cenovnik</span></a>
					<a href="ps4_iznajmljivanje_akcije.php" class="meni_a" title="Iznajmljivanje Sony Playstation 4 Akcije"><span class="meni_span">Akcije</span></a>
					<a href="ps4_iznajmljivanje_kontakt.php" class="meni_a" title="Iznajmljivanje Sony Playstation 4 Kontakt"><span class="meni_span" id="aktivan2">Kontakt</span></a>
					
				
			</div>
			
			<div id="container_sredina">
			
				<div id="container_slika">
				
						<div id="1"  class="slicica"><img src="Mihailo sajt slike/PS4-iznajmi-Beograd-soni4iznajmljivanje.rs_.jpg" height="100%" width="100%" alt="Iznajmljivanje sony4 Beograd"/></div>
						<div id="2"  class="slicica"><img src="Mihailo sajt slike/PES2016-Club-PS4 Iznajmljivanje.jpg" height="100%" width="100%" alt="PES 2016 iznajmljivanje PS4 Beograd"/></div>
						<div id="3"  class="slicica"><img src="Mihailo sajt slike/PS4_Iznajmljivanje_beograd_soni4_iznajmljivanje.jpg" height="100%" width="100%" alt="Najbolje igrice za iznajmljivanje za Sony Playstation 4 PS4iznajmljivanje.rs"/></div>
						<div id="4"  class="slicica"><img src="Mihailo sajt slike/Sony-4-iznajmljivanje-Beograd.jpg" height="100%" width="100%" alt="Iznajmljivanje PS4 Beograd"/></div>
						<div id="5"  class="slicica"><img src="Mihailo sajt slike/PlayStation4-sony 4 iznajmljivanje.jpg" height="100%" width="100%" alt="Igrice za sony4 | PS4 iznajmljivanje"/></div>
					
				</div>
				<div class="slika_preko">
				
					<div id="slika_preko_1" class="klasa_slika_preko">
						<h2 class="ispis_slika_preko" title="Popusti i akcije na Sony 4 iznajmljivanje!">Bonusi i akcije!</h2></br></br></br>
						<p class="ispis_p_slika_preko">AKCIJA 7 DANA - 6200rsd! Besplatna dostava, 2 po izboru, ostale po 100rsd dnevno. BONUS - Igrica! samo na www.ps4iznajmljivanje.rs!</p></br></br></br></br>
						<a href="ps4_iznajmljivanje_akcije.php" title="Detaljnije o akciji na PS4 iznajmljivanje Beograd" class="span"><span class="detaljnije"><i>Detaljnije ovde..</i></span></a>
					</div>
					
					<div id="slika_preko_2" class="klasa_slika_preko">
						<h2 class="ispis_slika_preko" title="FIFA 16 i PES 16 samo na PS4 iznajmljivanje Beograd!">Nova FIFA 16 i PES 16 su stigle!</h2></br></br>
						<p class="ispis_p_slika_preko">Pre samo nekoliko dana izasle su u prodaju, a vec se nalaze u nasoj kolekciji igara.
						Nedozvolite da neko do njih stigne pre Vas, iznajmite PS4 konzolu pozivom na broj </br>062/182-1998!</p></br></br>
						<a href="ps4_iznajmljivanje_igrice.php" class="span" title="Deljnije o igrama za Sony 4 na ps4iznajmljivanje.rs/igre"><span class="detaljnije"><i>Detaljnije ovde..</i></span></a>
					</div>

					<div id="slika_preko_3" class="klasa_slika_preko">
						<h2 class="ispis_slika_preko" title="Ogromna kolekcija igara za SONY 4 | Iznajmljivanje PS4 Beograd!">Ogromna kolekcija od cak 20 igara!</h2></br></br>
						<p class="ispis_p_slika_preko">Pri svakom iznajmljivanju mozete uzeti 2 igrica koje zelite! Ne zaboravite da imamo jednu od najvecih kolekcija  za PS4.</br> Iznajmljivanje na broj 062/182-1998!</p></br></br>
						<a href="ps4_iznajmljivanje_igrice.php" title="Deljnije o igrama za Sony 4 na ps4iznajmljivanje.rs/igre" class="span"><span class="detaljnije"><i>Detaljnije ovde..</i></span></a>
					</div>
					
					<div id="slika_preko_4" class="klasa_slika_preko">
						<h2 class="ispis_slika_preko" title="Akcije za iznajmljivanje sony 4 na PS4 iznajmljivanje Beograd!">Svakog radnog dana!</h2></br></br>
						<p class="ispis_p_slika_preko">Na Vracaru I na Starom gradu mozete iznajmiti SONY na sat, uz besplatno dostavu i 
										cenu od 150rsd po satu, maksimalno vreme iznajmljivanja je sest sati, sa zavrsnim terminom u 20h.</p></br></br>
						<a href="ps4_iznajmljivanje_akcije.php" title="Detaljnije o akciji na PS4 iznajmljivanje Beograd" class="span"><span class="detaljnije"><i>Detaljnije ovde..</i></span></a>
					
					</div>
					<div id="slika_preko_5" class="klasa_slika_preko">
						<h2 class="ispis_slika_preko" title="Novi PS4 na iznajmljivanje Beograd!">Pravila iznajmljivanja!</h2></br></br>
						<p class="ispis_p_slika_preko">Pri svakom iznajmljivanju morate ostaviti licnu kartu, sony povezujemo mi, uveravamo se da je isti ispravan. U slucaju bilo kakvog kvara 
						stetu moramo naplatiti. Iznajmljivanje moguce i putem facebook-a!</p></br></br>
						<a href="#pravila" class="span" title="Pravila iznajmljivanja Sony 4 Beograd"><span class="detaljnije"><i>Detaljnije ovde..</i></span></a>
					
					</div>
					
				</div>
				
				<div id="container_menjac">
					<div id='menjaci_drzac'>
						<a onclick="menjac(1);" class="a_menjac"><span class='menjac' id='menjac1'></span></a>
						<a onclick="menjac(2);" class="a_menjac"><span class='menjac' id='menjac2'></span></a>
						<a onclick="menjac(3);" class="a_menjac"><span class='menjac' id='menjac3'></span></a>
						<a onclick="menjac(4);" class="a_menjac"><span class='menjac' id='menjac4'></span></a>
						<a onclick="menjac(5);" class="a_menjac"><span class='menjac' id='menjac5'></span></a>
					</div>
				</div>
				
				<div id="container_sredina_trizanci">
					<div class="trizanci">
						<div class="trizanci_naslov_omotac">
								<div class="trizanci_krivi"><h1 class="trizanci_naslov" title="PS4 | Sony 4 iznajmljivanje Beograd 062/182-1998">PS4 Iznajmljivanje Beograd | Kontakt</h1></div></br>
						</div></br>
						<p class="trizanci_paragraf">Mozete nas kontaktirati SMS porukom, ili pozivom na broj <b>062/182-19-98</b>. Takodje, sve informacije mozete dobiti </br>email-om na <b>sony4iznajmljivanje@gmail.com</b>,
						ili popunjavanjem kontakt forme koje se nalazi ispod.
						</br></br>
						Popunite donji formular, posaljite poruku jednostavnim klikom i odgovor mozete ocekivati za manje od 24 sata. </br><b>PS4 Iznajmljivanje Beograd</b></p></br>
						
						<p class="trizanci_paragraf"><b>Vase ime i prezime:</b></p>
						
						<form name="formular" id="formular" enctype="multipart/form-data" method="POST">
								<input type="text" name="tbImePrezime" id="tbImePrezime" class="textForma"/></br></br>
								
							<p class="trizanci_paragraf"><b>Vas email:</b></p>
								<input type="text" name="tbEmail" id="tbEmail" class="textForma" /></br></br>
							
							<p class="trizanci_paragraf"><b>Tekst Vase poruke:</b></p>
								<textarea name="taTekst" id="taTekst" rows="7" cols="60" ></textarea></br></br>
								<input type="submit" class="btn" name="btnPosalji" id="btnPosalji" onclick="return Provera();" value="Posalji"/>
								<input type="reset" class="btn"  id="btnPonisti" value="Ponisti"/></br></br></br></br>
						</form>
					</div>
					
					<!--<div class="trizanci" id="pravila">
						
								<div class="trizanci_naslov_omotac">
									<div class="trizanci_krivi"><h1 class="trizanci_naslov" title="Pravila za iznajmljivanje PS4">Pravila Iznajmljivanja</h1></div></br>
								</div>
							
							<p class="trizanci_paragraf">Osnovno pravilo prilikom iznajmljivanja PS4 jeste da posedujete<b> licnu kartu</b>, radi nase sigurnosti o bilo kakvom kvaru.</br></br> U slucaju bilo kakve stete
							duzni ste da <b>isplatite istu!</b> Vreme iznajmljivanja traje od trenutka kada se <b>SONY ukljuci.</b></br></br> Usled velikog interesovanja za raznim vrstama igrica, moguce je biranje 2 besplatne igrice, 
							svaka sledeca igrica naplacuje se <b>100rsd.</b></br></br>
							Iznajmljivanje je moguce za sledece opstine:</br></br>
							&nbsp-<b> Zvezdara  , Vracar , Palilula , Vozdovac , Stari Grad , Savski Venac.</b> </br>
							&nbsp-	Za ostale delove grada cena po dogovoru. </br></br></br></p> ZA SLUCAJ DA ZATREBAJU JOS  JEDNI TRIZANCI -->
					</div>
				</div>
			</div>
				
		</div>
		
		<div id="footer">
			<p class="footer_ispis">Copyright © <?php echo date("Y");?> Nikola Mihajlovic | Soni 4 Iznajmljivanje. All rights reserved.</p>
		</div>
	</body>
</html>