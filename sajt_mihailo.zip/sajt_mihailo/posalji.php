﻿<?php 
	if(isset($_GET['tbImePrezime']))
	{
		$ime=$_REQUEST['tbImePrezime'];
		$email=$_REQUEST['tbEmail'];
		$tekst=$_REQUEST['taTekst'];
		
		mail('mihailostojkovic22@gmail.com','Postovani,',$tekst.' od: '.$ime.' email: '.$email,'Od: '.$email);
	}
?>