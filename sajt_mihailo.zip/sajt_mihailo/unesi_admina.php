﻿<?php session_start();
	if(isset($_REQUEST['btnUnesiAdmina']))
	{
		$uloga=$_REQUEST['tbUloga'];
		$username=$_REQUEST['tbUser'];
		$pass=$_REQUEST['tbPass'];
		$passMD5=md5($pass);
		$uloga=addslashes($uloga);
		$username=addslashes($username);
		$pass=addslashes($pass);
		
		include("konekcija.inc");
		
		$upit="INSERT INTO admin (id,uloga,password,username) VALUES ('','".$uloga."','".$passMD5."','".$username."')";
		
		if(mysql_query($upit))
		{
			header("Location:ps4_iznajmljivanje_admin.php");
		}
		else
		{
			echo("Error: ".mysql_error());
		}
		mysql_close();
	}
	if(isset($_REQUEST['btnUnesiAkciju']))
	{
		include("konekcija.inc");
		$tip=$_REQUEST['tbTip'];
		$tekst=$_REQUEST['tbTekst'];
		$tip=addslashes($tip);
		$tekst=addslashes($tekst);
		
		$query="INSERT INTO akcije (id,tip_akcije,tekst) VALUES ('','".$tip."','".$tekst."')";
		if(mysql_query($query))
		{
			header("Location:ps4_iznajmljivanje_admin.php");
		}
		else
		{
			echo("Error: ".mysql_error());
		}
		mysql_close();
	}
	if(isset($_REQUEST['btnUnesiDnevni']))
	{
		$tip=$_REQUEST['tbTipDnevnog'];
		$tekst=$_REQUEST['tbTekstDnevnog'];
		$tip=addslashes($tip);
		$tekst=addslashes($tekst);
		
		include("konekcija.inc");
		$upit="INSERT INTO dnevne (id,tip,tekst) VALUES ('','".$tip."','".$tekst."')";
		if(mysql_query($upit))
		{
			header("Location:ps4_iznajmljivanje_admin.php");
		}
		else
		{
			echo("Error: ".mysql_error());
		}
		mysql_close();
	}
	if(isset($_REQUEST['btnUnesiIgricu']))
	{
		$ime=$_REQUEST['tbIme'];
		$ime=addslashes($ime);
		$file_ime=$_FILES['file']['name'];
		include("konekcija.inc");
		$putanja="Mihailo sajt slike/igrice/".$file_ime;
		
		move_uploaded_file($_FILES['file']['tmp_name'], $putanja);
		
		$upit="INSERT INTO igrice (id,ime,putanja) VALUES ('','".$ime."','".$putanja."')";
		if(mysql_query($upit))
		{
			header("Location:ps4_iznajmljivanje_admin.php");
		}
		else
		{
			echo("Error: ".mysql_error());
		}
		mysql_close();
		
	}
	if(isset($_REQUEST['btnUnesiIgricuProdaja']))
	{
		$ime=$_REQUEST['tbImeProdaja'];
		$ime=addslashes($ime);
		$file_ime=$_FILES['fileProdaja']['name'];
		include("konekcija.inc");
		$putanja="Mihailo sajt slike/igrice_prodaja/".$file_ime;
		
		move_uploaded_file($_FILES['fileProdaja']['tmp_name'], $putanja);
		
		$upit="INSERT INTO igrice_prodaja (id,ime,putanja) VALUES ('','".$ime."','".$putanja."')";
		if(mysql_query($upit))
		{
			header("Location:ps4_iznajmljivanje_admin.php");
		}
		else
		{
			echo("Error: ".mysql_error());
		}
		mysql_close();
	}
	if(isset($_REQUEST['btnUnesiCenu']))
	{
		include("konekcija.inc");
		$sati=$_REQUEST['tbSati'];
		$cena=$_REQUEST['tbCena'];
		$tip=$_REQUEST['ddlTip'];
		$upit="INSERT INTO cenovnik (id,sati,cena,tip) VALUES ('','".$sati."','".$cena."',".$tip.")";
		if(mysql_query($upit))
		{
			header("Location:ps4_iznajmljivanje_admin.php");
			
		}
		else
		{
			echo("Error: ".mysql_error());
		}
		mysql_close();
	}
?>