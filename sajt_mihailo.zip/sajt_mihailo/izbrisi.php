﻿<?php
if(isset($_GET['id']))
{
		include("konekcija.inc");
		$id=$_REQUEST['id'];
		$upit="DELETE FROM admin WHERE id=".$id;
		if(mysql_query($upit))
		{
			header("Location:ps4_iznajmljivanje_admin.php");
		}
		else
		{
			
		}
		mysql_close();
	}
	else if(isset($_GET['id_akcije']))
	{
		include("konekcija.inc");
		$id_akcije=$_REQUEST['id_akcije'];
		$upit2="DELETE FROM akcije WHERE id=".$id_akcije;
		if(mysql_query($upit2))
		{
			header("Location:ps4_iznajmljivanje_admin.php");
		}
		else
		{
			
		}
		mysql_close();
	}
	else if(isset($_GET['id_dnevne']))
	{
		include("konekcija.inc");
		$id=$_GET['id_dnevne'];
		$ttt="DELETE FROM dnevne WHERE id=".$id;
		if(mysql_query($ttt))
		{
			header("Location:ps4_iznajmljivanje_admin.php");
		}
		else
		{
			
		}
		mysql_close();
	}
	else if(isset($_GET['id_igrice']))
	{
		include("konekcija.inc");
		$id=$_GET['id_igrice'];
		$oro="DELETE FROM igrice WHERE id=".$id;
		if(mysql_query($oro))
		{
			header("location:ps4_iznajmljivanje_admin.php");
		}
		else
		{
			
		}
		mysql_close();
	}
	else if(isset($_GET['id_igrice_prodaja']))
	{
		include("konekcija.inc");
		$id=$_GET['id_igrice_prodaja'];
		$zoro="DELETE FROM igrice_prodaja WHERE id=".$id;
		if(mysql_query($zoro))
		{
			header("location:ps4_iznajmljivanje_admin.php");
		}
		else
		{
			
		}
		mysql_close();
	}
	else if(isset($_GET['id_cene']))
	{
		include("konekcija.inc");
		$id=$_GET['id_cene'];
		$kolo="DELETE FROM cenovnik WHERE id=".$id;
		if(mysql_query($kolo))
		{
			header("Location:ps4_iznajmljivanje_admin.php");
			
		}
		else
		{
			
		}
		mysql_close();
	}
	else
	{
		header("Location:index.php");
	}
	
?>