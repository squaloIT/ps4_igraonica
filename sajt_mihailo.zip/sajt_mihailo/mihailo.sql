-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 30, 2015 at 12:30 AM
-- Server version: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `mihailo`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL,
  `uloga` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `username` varchar(20) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `uloga`, `password`, `username`) VALUES
(6, 'admin', 'a35ff1d37166ed80f208263bcdeb6d19', 'adminadmin');

-- --------------------------------------------------------

--
-- Table structure for table `akcije`
--

CREATE TABLE IF NOT EXISTS `akcije` (
  `id` int(11) NOT NULL,
  `tip_akcije` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `tekst` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `lajkovi` int(11) NOT NULL,
  `dislajkovi` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `akcije`
--

INSERT INTO `akcije` (`id`, `tip_akcije`, `tekst`, `lajkovi`, `dislajkovi`) VALUES
(14, 'AKCIJA ZVEZDARA ', '- Iznajmljivanje na sat u vremenskom intervalu od 11h do 20h, cena po satu je <b><i>150rsd</b></i> sa 2 dzoistika, dok je za cetiri dzoistika <b><i>200rsd</b></i> po satu, besplatna dostava, 2 igrice po izboru.', 2, 0),
(16, 'AKCIJA STARI GRAD I SAVSKI VENAC', '- Iznajmljivanje na sat u vremenskom intervalu od 11h do 20h , cena po satu je <b><i>100rsd</i></b> , dok je za cetiri dzoistika <b><i>200rsd</i></b> po satu, besplatna dosta, 2 igrice po izboru.</br>Radnim danima - <b>gratis 1h.</b>', 1, 0),
(17, 'AKCIJA VOZDOVAC', '- Iznajmljivanje na sat u vremenskom intervalu 12h do 19h, cena po satu je <b><i>180rsd</i></b> , dok je za cetiri dzoistika <b><i>200rsd</i></b> po satu, 2 igrice po izboru.', 1, 0),
(18, 'AKCIJA SAVSKI VENAC', 'â€“ radnim danima u vremenskom intervalu od 12h do 19h, mozete iznajmiti za samo <b><i>799rsd.</i></b>', 1, 0),
(19, 'Akcija ZVEZDARA ', 'â€“ radnim danima u vremenskom intervalu od 12h do 19h, mozete iznajmiti za samo <b><i>799rsd.</i></b>', 1, 0),
(20, 'AKCIJA 7 DANA', '- 6200rsd! Besplatna dostava, 2 po izboru, ostale po <b><i>150rsd</i></b> dnevno. BONUS - Igrica	', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `cenovnik`
--

CREATE TABLE IF NOT EXISTS `cenovnik` (
  `id` int(11) NOT NULL,
  `sati` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `cena` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `tip` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cenovnik`
--

INSERT INTO `cenovnik` (`id`, `sati`, `cena`, `tip`) VALUES
(1, '24h', '- 1800 rsd.', 1),
(2, '48h', '- 3000 rsd.', 1),
(3, '72h', ' - 4000 rsd. +gratis 12h <b>BONUS</b> - Igrica', 1),
(4, '24h', ' - 2200 rsd.', 2),
(5, '48h ', ' - 4000rsd + gratis 12h <b>BONUS</b> - 2 igrice', 2),
(6, '12h', ' - 1200 rsd.', 3),
(7, '8h ', '- 950 rsd.', 3),
(9, '6h', '- 750 rsd.', 3);

-- --------------------------------------------------------

--
-- Table structure for table `dnevne`
--

CREATE TABLE IF NOT EXISTS `dnevne` (
  `id` int(11) NOT NULL,
  `tip` varchar(80) CHARACTER SET utf32 COLLATE utf32_unicode_ci NOT NULL,
  `tekst` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `igrice`
--

CREATE TABLE IF NOT EXISTS `igrice` (
  `id` int(11) NOT NULL,
  `ime` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `putanja` varchar(120) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `igrice`
--

INSERT INTO `igrice` (`id`, `ime`, `putanja`) VALUES
(3, 'FIFA 16', 'Mihailo sajt slike/igrice/fifa16_ps4_iznajmljivanje.jpg'),
(6, 'GTA V', 'Mihailo sajt slike/igrice/GTAV-PS4_iznajmljivanje.jpg'),
(10, 'NBA 2k16', 'Mihailo sajt slike/igrice/nba_2k16-ps4_iznajmljivanje.jpg'),
(15, 'Call of Duty', 'Mihailo sajt slike/igrice/fbaaf1479c884691635019e9c7521928.jpg'),
(16, 'Battlefield 4', 'Mihailo sajt slike/igrice/battlefield-4-ps4_iznajmljivanje_Beograd.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `akcije`
--
ALTER TABLE `akcije`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cenovnik`
--
ALTER TABLE `cenovnik`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dnevne`
--
ALTER TABLE `dnevne`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `igrice`
--
ALTER TABLE `igrice`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `akcije`
--
ALTER TABLE `akcije`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `cenovnik`
--
ALTER TABLE `cenovnik`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `dnevne`
--
ALTER TABLE `dnevne`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `igrice`
--
ALTER TABLE `igrice`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=18;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
