﻿function Provera()
{
	var lose=false;
	var ime=document.getElementById("tbImePrezime").value;
	var email=document.getElementById("tbEmail").value;
	var tekst=document.getElementById("taTekst").value;
	var imeTest=/^[A-Z]{1}(\w+)\s[A-Z]{1}(\w+)$/;
	var emailTest=/^[A-Za-z0-9\-\_\.]{1,}@[A-Za-z0-9\-\_]{3,}\.(\w){1,6}$/;
	

	if(ime=="")
	{
		$('#tbImePrezime').css("border","2px solid red");
		return false;
	}
	else if(!imeTest.test(ime))
	{
		$('#tbImePrezime').css("border","2px solid red");
		return false;	
	}
	else if(email=="")
	{
		$('#tbEmail').css("border","2px solid red");
		return false;
	}
	else if(!emailTest.test(email))
	{
		$('#tbEmail').css("border","2px solid red");
		return false;
	}
	else if(tekst=="")
	{
		$('#taTekst').css("border","2px solid red");
		return false;
	}
	else
	{
		$.ajax({
							
							type:"GET",
							url:"posalji.php?tbImePrezime="+ime+"&tbEmail="+email+"&taTekst="+tekst,
							
							success: function()
							{
								alert("Vas mail je uspesno poslat.");
							}
				});

		return true;
	}
	
	
}